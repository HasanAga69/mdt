fx_version 'cerulean'
game 'gta5'

shared_script 'sh_config.lua'
server_script 'sv_main.lua'
client_script 'cl_main.lua'

ui_page 'interface/index.html'

files {'interface/*'}