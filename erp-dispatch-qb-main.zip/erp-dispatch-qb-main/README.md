# Dispatch System

Dispatch system that works with our mdt.

Available alerts:

[+] un-dispatch:bankrobbery - Bank Robbery

[+] un-dispatch:storerobbery - Store Robbery

[+] un-dispatch:houserobbery - House Robbery

[+] un-dispatch:jewelrobbery - Vangelico Robbery

[+] un-dispatch:jailbreak - Jail Break

[+] un-dispatch:carjacking - Vehicle Theft

[+] un-dispatch:gunshot - Shots Fired
